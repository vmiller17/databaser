<html>
<head><title>Main page</title><head>
<body><h1>Main page</h1>
	<p>
	What to do:
	<p>
	<form method=post action="search.php">		
		<input type=submit value="Search">
	</form>
	<form method=post action="block.php">		
		<input type=submit value="Block Pallet(s)">
	</form>
	<form method=post action="simulate.php">		
		<input type=submit value="Simulate production">
	</form>
</body>
</html>
