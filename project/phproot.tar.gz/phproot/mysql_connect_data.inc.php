<?php
	$host = "puccini.cs.lth.se";
	$userName = "db30";
	$password = "ibanez17";
	$database = "db30";
?>
